
<h1>This is CakePHP tutorial and this is an example of connecting routes.</h1>
